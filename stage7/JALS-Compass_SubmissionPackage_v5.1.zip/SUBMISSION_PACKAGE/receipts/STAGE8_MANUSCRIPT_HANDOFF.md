# Stage 8 — Manuscript & Cover Letter Handoff
*Timestamp:* 2025-11-08 13:50 UTC  
*Commit:* 36d18f1  

## Action
This marks the transition from Stage 7 (package verified)  
to Stage 8 (manuscript & cover letter insertion).  

Place the final files here:
- `manuscript/Manuscript_v5.1.pdf`
- `manuscript/Cover_Letter_v5.1.pdf`

Once inserted, run the “final-seal” script to hash and archive the completed package.
