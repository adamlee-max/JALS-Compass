# Figures Drop Folder
Expected files:
- Fig1_Framework_Overview.pdf
- Fig2_Ct_Drift.pdf
- Fig3_NullModel_Collapse.pdf

If using PNGs, ensure ≥ 300 DPI. Keep figure captions in the manuscript; short alt text may be added here if required.
