# Manuscript Drop Folder
Place the final **Manuscript.pdf** and **Cover_Letter.pdf** here.

## Preflight checklist
- Fonts embedded
- Vector figures (PDF/SVG) or high-DPI PNG
- All references resolved
- Internal cross-refs (figures, sections) correct
- Receipt links present in appendix/footnotes
