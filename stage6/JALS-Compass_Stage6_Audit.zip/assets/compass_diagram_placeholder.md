# Compass Diagram Placeholder

This file marks the spot for a simple visual.

**Planned content:**  
A one-page sketch showing the five invariants in a circle:
- Boundary (outer ring)
- Centre (middle point)
- Loops (arrows around)
- Patterns (shapes within)
- History (timeline underneath)

Image will be added in future as `compass_diagram_v3.3.png`.
